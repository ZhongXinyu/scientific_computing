This is a library that perform numerical integration
